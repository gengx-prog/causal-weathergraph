# Supplementary Data for "Causal WeatherGraph: screen-confirm-replicate discovery of lagged wind-humidity-cloud dependencies in global atmospheric reanalysis"

All files are comma-separated. Variables: temperature (T), humidity (H, 850-hPa specific humidity), wind (W, 850-hPa wind speed), cloud_cover (C, total cloud cover).
Lags are in 6-hour steps. Coefficients are in units of discovery-period standard deviations of the regional anomaly series.

* S0_regions.csv - the 66 regions: identifier, centroid latitude and longitude (circular mean), number of 5.625-degree grid cells.
* S1_three_stage_all_candidates.csv - all 2,574 edge-lag hypotheses of the physics-guided candidate set.
  - s1_*: Stage 1, own-history regression on 1979-2018 (effect, HAC64 p, global BH q, partial R2); s1_pass = q < 0.05.
  - s2_*: Stage 2, dense VAR(3) on 1979-2018 (effect, HAC64 p and SE, global BH q, partial R2); s2_pass = Stage 1 and q < 0.05.
  - eval_wb2_*, eval_cds_*, eval_all_*: held-out segments 2019-01-01..2023-01-10 (WeatherBench 2, primary), 2023-01-11..2025-12-31
    (native CDS fields with the same conservative regridding, second replication segment) and their union.
    *_effect, *_p, *_partial_r2: dense VAR(3) refitted in the segment; *_p1: one-sided same-sign p-value; *_q_rep: BH within the confirmed family;
    *_replicated: confirmed and q_rep < 0.05; *_gain, *_gain_se, *_gain_p1, *_gain_q_rep, *_relative_gain: frozen 1979-2018 drop-one predictive gain;
    *_predictive: confirmed, gain > 0 and gain q < 0.05; *_own_*: own-history model in the segment; *_negctrl_q: replication q-value for unconfirmed hypotheses.
* S2_symmetric_full_var_<period>.csv - 3,816 edge-lag hypotheses of the symmetric candidate set (W<->H, H<->C, W<->C) under dense VAR(3) in each period
  (column/outcome index the VAR design; effect, se_hac64, p_hac64, q_hac64_global, se_ols, p_ols, partial_r2, delta_r2, n_samples).
* S3_regime_screening_ols_hac.csv - 18,018 full-record edge-lag-regime screening tests (own-history regression, 1979-2025 climatology) with OLS and HAC (32, 64, 128) inference,
  within-family (regime x target variable) and global BH q-values, effect sizes and residual autocorrelations at 6, 24, 72 and 168 h.
* S4_ceres_substitution_tests.csv - own-history and dense VAR(3) tests of the 2,544 symmetric cloud hypotheses with ERA5 cloud and with CERES SYN1deg Ed4.2 cloud
  (product), by segment (2017_2025, wb2 = 2017-01-01..2023-01-10, cds = 2023-01-11..2025-12-31) and climatology (month or month x UTC hour).
* S5a/S5b - same-date comparison of WeatherBench 2 with fields requested on the CDS 5.625-degree grid (interpolated; used for 2023-2025 in the
  original submission) on 152 timestamps: variable-level statistics (physical, grid-standardized and regional-standardized scales, and by
  latitude band) and region-level bias, RMSE and correlation.
* S5c - the same comparison for native 0.25-degree CDS fields regridded with the WeatherBench 2 conservative scheme (used for
  2023-01-11..2025-12-31 in this revision), beside the interpolation route (column route).
* S6a_whec_design.json - design of the wind-humidity eddy convergence (WHEC) test, frozen before any of its results were computed
  (SHA-256 0507157c5a8ec0b248a36bca29818af6623ba86b1e19576f57fd743d92beee92). WHEC_r is minus the regional mean of div(u'q') at 850 hPa
  (u', q': anomalies from the 1979-2018 calendar-month climatology); LIN_r uses the linear increment, PLAC_r uses q' taken 365 days earlier.
* S6b_whec_tests_per_lag.csv - the 1,188 lag-specific hypotheses (families A_local_whec, B_remote_whec, C_placebo; targets humidity and
  cloud_cover; lags 1-3): s1_* own-history screen, s2_* augmented dense VAR(3) in 1979-2018, eval_* held-out refits and frozen gains,
  replication and negative-control q-values, with the same rules as S1.
* S6c_whec_block_tests.csv - per family, target and region: block Wald tests of the three test-series lags in each period
  (period = discovery or eval_*) and frozen 1979-2018 block gains on each held-out segment (period = frozen_eval_*).
* S6d_whec_band_endpoints.csv - band means and band differences of the region-normalized frozen block gains with HAC64 standard errors,
  z-statistics and one-sided p-values (primary endpoints E1: family A, cloud_cover, midlatitude; E2: midlatitude_minus_tropical).
* S6e_whec_ceres_check.csv - lag-specific test-series coefficients in refits on 2017-01-01..2023-01-10 and 2023-01-11..2025-12-31 with
  ERA5 or CERES cloud as predictor and outcome; p1 is one-sided for the 1979-2018 sign, q is BH within product, period and family.
